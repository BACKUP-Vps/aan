<?php

return [
    'welcome' => [
        'title'   => 'Bem-vindo!',
        'message' => 'Bem-vindo ao :appname',
    ],
];
