<?php

return [
    'avatarresize' => 'Este avatar será redimensionado para :width x :height pixels',

    'newapikey'       => 'Nova Chave API',
    'your-profile'    => 'Seu Perfil',
    'your-awards'     => 'Seus Prêmios',
    'apikey'          => 'Chave API',
    'apikey-show'     => 'Mostrar chave',
    'dontshare'       => 'Não compartilhe isso!',
    'changepassword'  => 'Mudar Senha',
    'newpassword'     => 'Nova Senha',
    'avatar'          => 'Avatar',
    'updateprofile'   => 'Atualizar Perfil',
    'editprofile'     => 'Editar Perfil',
    'edityourprofile' => 'Editar seu perfil',
    'transferhours'   => 'Horas Transferidas',
    'opt-in'          => 'Opt-In',
    'opt-in-descrip'  => 'Sim, inclua-me em emails não administrativos',
];
