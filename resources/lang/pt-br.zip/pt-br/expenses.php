<?php

return [
    'type' => [
        'flight'  => 'Voo',
        'daily'   => 'Diariamente',
        'monthly' => 'Mensalmente',
    ],
];
