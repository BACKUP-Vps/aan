<?php

return [
    'status' => [
        'active'      => 'Ativa',
        'maintenance' => 'Manutencao',
        'stored'      => 'Armazenada',
        'retired'     => 'Retirada',
        'scrapped'    => 'Sucateada',
        'written'     => 'Eliminada',
    ],
];
