<?php

return [
    'none' => 'Não há downloads!',
];
