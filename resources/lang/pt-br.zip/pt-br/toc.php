<?php

return [
    'title' => 'Termos e Condições',
];
