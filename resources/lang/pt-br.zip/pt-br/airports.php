<?php

return [
    'ident'     => 'Identificação',
    'home'      => 'Aeroporto local',
    'current'   => 'Aeroporto atual',
    'departure' => 'Aeroporto de Partida',
    'arrival'   => 'Aeroporto de Chegada',
];
