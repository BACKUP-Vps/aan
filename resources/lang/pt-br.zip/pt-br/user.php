<?php

return [
    'location' => 'Localização',
    'state'    => [
        'pending'   => 'Pendente',
        'active'    => 'Ativo',
        'rejected'  => 'Rejeitado',
        'on_leave'  => 'Em licença',
        'suspended' => 'Suspensa',
        'deleted'   => 'Excluído',
    ],
];
