<?php

return [
    'totalhours'     => 'Total de horas',
    'yourbalance'    => 'Seu balanço',
    'yourlastreport' => 'Seu último PIREP',
    'noreportsyet'   => 'Ainda não há PIREPs.',
    'fileonenow'     => 'Envie um agora.',
    'weatherat'      => 'Tempo em :ICAO',
    'recentreports'  => 'Reportes Recentes',
];
