<?php

return [
    'buttontroubles' => 'Se você estiver com problemas para clicar no botão ":actiontext", '.
        'copie e cole a URL abaixo no seu navegador:',
];
